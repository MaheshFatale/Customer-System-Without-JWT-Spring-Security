package in.sunbase.service;

import java.util.List;
import in.sunbase.entity.CustomerEntity;
import in.sunbase.entity.SearchCustomer;

public interface CustomerService {
	
	public List<CustomerEntity> getSearchCust(SearchCustomer searcust);
	public List<CustomerEntity> getAllCustomer1();
	public void saveCustomerEntity(CustomerEntity cust);
	public void updateCustomerEntity(Integer cid,CustomerEntity cust);
	public CustomerEntity getCustomerById(Integer cid);
	public void deleteCustomerEntity(Integer cid);

}
