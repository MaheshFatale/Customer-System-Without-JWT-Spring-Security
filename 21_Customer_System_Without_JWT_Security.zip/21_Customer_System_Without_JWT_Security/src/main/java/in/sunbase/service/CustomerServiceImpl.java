package in.sunbase.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import in.sunbase.entity.CustomerEntity;
import in.sunbase.entity.SearchCustomer;
import in.sunbase.repository.CustomerRepository;
import reactor.core.publisher.Mono;

@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	private CustomerRepository repo;
		
//	private String Get_All_Customer="http://localhost:9191/api/allcustomer";				  //1.get (pagination)
	private String Get_all_Record="http://localhost:9191/api/allrecordcustomer";			  //1.get
//	private String Delete_ById="http://localhost:9191/api/deletecustomer/{cid}";			  //2.delete
//	private String Get_Customer_By_Cid="http://localhost:9191/api/findcustomer/{cid}";	   	  //3.get
	private String Save_Customer="http://localhost:9191/api/savecustomer";					  //4.post
//	private String Search_Customer_By_searchCust="http://localhost:9191/api/searchcustomer";  //5.post
	private String Put_Customer="http://localhost:9191/api/updatecustomer/{cid}";			  //6.put
	
	
//1.AllCustomer
	public List<CustomerEntity> getAllCustomer1()
	{	/**
		WebClient webClient=WebClient.create();
		List<CustomerEntity> customer=	webClient.get()
										.uri("Get_all_Record")
										.retrieve()
										.bodyToFlux(CustomerEntity.class)
 										.collectList()
										.block();
	*/
		WebClient webClient=WebClient.create();
		Mono<List<CustomerEntity>> response = webClient.get()
				  							  .uri(Get_all_Record)
				  							  .retrieve()
				  							  .bodyToMono(new ParameterizedTypeReference<List<CustomerEntity>>() {});
		List<CustomerEntity> customer = response.block();
		for (CustomerEntity customerEntity : customer) {
				repo.save(customerEntity);
		}
		return repo.findAll();
	}
	
//2.Delete by id	
	public void deleteCustomerEntity(Integer cid) {
/**		WebClient webClient=WebClient.create();
		CustomerEntity	c1=	webClient
							.delete()
							.uri("Delete_ById" + cid)
							.retrieve()
							.bodyToMono(CustomerEntity.class)
							.block();
*/															
		repo.deleteById(cid);
	}
	
//3.Get Customer by id
	@Override
	public CustomerEntity getCustomerById(Integer cid) {
/**		WebClient webclint=WebClient.create();
		CustomerEntity customer=webclint.get()
								.uri(Get_Customer_By_Cid + cid)
								.retrieve()
								.bodyToMono(CustomerEntity.class)
								.block();	
*/
		return repo.getById(cid);
	}
	
//4.Save Customer	
	@Override
	public void saveCustomerEntity(CustomerEntity cust) {
		WebClient webClient=WebClient.create();
								webClient
								.post()
								.uri(Save_Customer)
								.bodyValue(cust)
								.retrieve()
								.bodyToMono(CustomerEntity.class)
								.subscribe();
		repo.save(cust);
		
	}

//5.search customer by search customer
	public List<CustomerEntity> getSearchCust(SearchCustomer searcust) {
		CustomerEntity c1=new CustomerEntity();
		if(!searcust.getFirst_Name().isEmpty() && !"".equals(searcust.getFirst_Name()))
		c1.setFirst_Name(searcust.getFirst_Name());
		
		if(!searcust.getCity().isEmpty() && !"".equals(searcust.getCity()))
		c1.setCity(searcust.getCity());
		
		if(!searcust.getEmail().isEmpty() && !"".equals(searcust.getEmail()))
		c1.setEmail(searcust.getEmail());
		
		if(!searcust.getPhoneNo().isEmpty() && !"".equals(searcust.getPhoneNo()))
		c1.setPhoneNo(searcust.getPhoneNo());
/**
	//	repo.findAll(Example.of(c1));
		WebClient webclint=WebClient.create();
		@SuppressWarnings("unchecked")
		List<CustomerEntity> customer=(List<CustomerEntity>) webclint.post()
									.uri(Search_Customer_By_searchCust,c1)
									.retrieve()
									.bodyToFlux(CustomerEntity.class)
									.collectList()
									.block();
*/
		return 	repo.findAll(Example.of(c1));
	}
	
//6.Update Customer
	@Override
	public void updateCustomerEntity(Integer cid, CustomerEntity cust) {
		WebClient webclint=WebClient.create();
						   webclint.put()
						   .uri(Put_Customer,cid)
						   .bodyValue(cust)
						   .retrieve()
						   .bodyToMono(CustomerEntity.class)
						   .subscribe();
		if(repo.existsById(cid))
			repo.save(cust);
	}
	
}
