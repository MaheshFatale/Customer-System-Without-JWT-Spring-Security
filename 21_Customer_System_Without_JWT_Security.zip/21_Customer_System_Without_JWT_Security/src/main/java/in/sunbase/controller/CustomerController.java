package in.sunbase.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import in.sunbase.entity.CustomerEntity;
import in.sunbase.entity.SearchCustomer;
import in.sunbase.repository.CustomerRepository;
import in.sunbase.service.CustomerService;

@Controller
public class CustomerController {
	
	@Autowired
	private CustomerRepository repo;
	
	@Autowired
	private CustomerService service;

	@PostMapping("/searchCustomer")
	public String findCustomer(@ModelAttribute("cust") SearchCustomer searcust,Model model)
	{
		model.addAttribute("custs", service.getSearchCust(searcust));
		return "index";
	}
		
	@GetMapping("/CreateCustomer")
	public String loadCustomerForm(Model model)
	{
		model.addAttribute("cust", new CustomerEntity());
		return "CreateCustomer";
	}
	
	@GetMapping("/delete")
	public String deleteCustomer(@RequestParam("cid")Integer cid,Model model)
	{
		service.deleteCustomerEntity(cid);
		init(model);
		return "index";
	}
	
	@GetMapping("/update")
	public String updateCustomer(@RequestParam("cid") Integer cid,Model model)
	{
		model.addAttribute("cust", service.getCustomerById(cid));
		return "CreateCustomer";
	}
	
	@PostMapping("/saveCustomer")
	public String handleSave(Model model, CustomerEntity cust)
	{	
		service.saveCustomerEntity(cust);
		init(model);
		return "index";
	}
	
	@GetMapping("/")
	public String Form2(Model model)
	{
		init(model);	
		return "index";
	}	

	@GetMapping("/sync")
	public String loadForm1(Model model)
	{
		model.addAttribute("cust", new SearchCustomer());
		model.addAttribute("custs", service.getAllCustomer1());	
		return "index";
	}
	
	private void init(Model model) {
		model.addAttribute("cust", new CustomerEntity());
		model.addAttribute("custs", repo.findAll());
	}
}
