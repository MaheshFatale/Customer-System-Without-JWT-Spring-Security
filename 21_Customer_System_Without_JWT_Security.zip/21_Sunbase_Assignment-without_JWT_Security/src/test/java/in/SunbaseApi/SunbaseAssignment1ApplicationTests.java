package in.SunbaseApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SunbaseAssignment1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
