package in.SunbaseApi.search;

import lombok.Data;

@Data
public class SearchCustomer {

	private String first_Name;
	private String city;
	private String email;
	private String phoneNo;
}
